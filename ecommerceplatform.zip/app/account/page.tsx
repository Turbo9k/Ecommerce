import { AccountOverview } from "@/components/account-overview"

export default function AccountPage() {
  return <AccountOverview />
}
